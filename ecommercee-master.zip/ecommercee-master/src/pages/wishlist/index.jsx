import React from 'react'

const Wishlist = () => {
  return (
    <div>Wishlist</div>
  )
}

export default Wishlist