export { default as AboutUs } from "./aboutus"
export { default as Checkout} from "./checkout"
export { default as DetailProduct } from "./detailproduct";
export { default as Home } from "./home";
export { default as Login } from "./login";
export { default as Payment } from "./payment"
export { default as Profile } from "./profile"
export { default as Register } from "./register"
export { default as Vouchers } from "./vouchers"
export { default as WishList } from "./wishlist"