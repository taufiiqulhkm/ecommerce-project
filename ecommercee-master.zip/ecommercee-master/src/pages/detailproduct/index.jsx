import React from 'react'

const DetailProduct = () => {
  return (
    <div>DetailProduct</div>
  )
}

export default DetailProduct