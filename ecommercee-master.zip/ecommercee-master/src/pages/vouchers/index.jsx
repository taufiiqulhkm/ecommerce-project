import React from 'react'

const Vouchers = () => {
  return (
    <div>Vouchers</div>
  )
}

export default Vouchers