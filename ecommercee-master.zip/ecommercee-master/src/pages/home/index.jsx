import React from 'react'
import { Navbar } from '@components'

const Home = () => {
  return (
    <div>
      <Navbar/>
    </div>
  )
}

export default Home