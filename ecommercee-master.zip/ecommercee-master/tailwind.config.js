/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./src/**/*.{html,js,css,jsx}"],
    theme: {
        extend: {},
    },
    plugins: [],
}